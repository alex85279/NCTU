#include <stdio.h>
#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include "Util.h"
#include "Command.h"
#include "Table.h"

///
/// Allocate State_t and initialize some attributes
/// Return: ptr of new State_t
///

int id_c = 1;
int name_c = 1;
int email_c = 1;
int age_c = 1;
int coma_total = 0;
int field_num[10];
State_t* new_State() {
    State_t *state = (State_t*)malloc(sizeof(State_t));
    state->saved_stdout = -1;
    return state;
}

///
/// Print shell prompt
///
void print_prompt(State_t *state) {
    if (state->saved_stdout == -1) {
        printf("db > ");
    }
}

///
/// Print the user in the specific format
///
void print_user(User_t *user) {
    int tmp_total = coma_total;
    //printf("(%d, %s, %s, %d)\n", user->id, user->name, user->email, user->age);
    /*printf("(");
    if(tmp_total>0 && id_c == 1){
	printf("%d",user->id);
	if(tmp_total>1){
	    printf(", ");		
	}
	tmp_total--;
    }
    if(tmp_total>0 && name_c == 1){
	printf("%s",user->name);
	if(tmp_total>1){
	    printf(", ");		
	}
	tmp_total--;
    }
    if(tmp_total>0 && email_c == 1){
	printf("%s",user->email);
	if(tmp_total>1){
	    printf(", ");		
	}
	tmp_total--;
    }
    if(tmp_total>0 && age_c == 1){
	printf("%d",user->age);
	if(tmp_total>1){
	    printf(", ");		
	}
	tmp_total--;
    }
    printf(")\n");*/
    printf("(");

    for(int i = 0; i<tmp_total;i++){
	if(field_num[i] == 0){
	    printf("%d",user->id);	
	}
	else if(field_num[i] == 1){
	    printf("%s",user->name);	
	}
	else if(field_num[i] == 2){
	    printf("%s",user->email);	
	}
	else if(field_num[i] == 3){
	    printf("%d",user->age);	
	}
	if(i != tmp_total-1){
	    printf(", ");
	}
    }
    printf(")\n");
}

///
/// This function receivedyan output argument
/// Return: category of the command
///
int parse_input(char *input, Command_t *cmd) {
    char *token;
    int idx;
    token = strtok(input, " \n,");
    for (idx = 0; strlen(cmd_list[idx].name) != 0; idx++) {
        if (!strncmp(token, cmd_list[idx].name, cmd_list[idx].len)) {
            cmd->type = cmd_list[idx].type;
        }
    }
    while (token != NULL) {
        add_Arg(cmd, token);
        token = strtok(NULL, " \n,");
    }
    return cmd->type;
}

///
/// Handle built-in commands
/// Return: command type
///
void handle_builtin_cmd(Table_t *table, Command_t *cmd, State_t *state) {
    if (!strncmp(cmd->args[0], ".exit", 5)) {
        archive_table(table);
        exit(0);
    } else if (!strncmp(cmd->args[0], ".output", 7)) {
        if (cmd->args_len == 2) {
            if (!strncmp(cmd->args[1], "stdout", 6)) {
                close(1);
                dup2(state->saved_stdout, 1);
                state->saved_stdout = -1;
            } else if (state->saved_stdout == -1) {
                int fd = creat(cmd->args[1], 0644);
                state->saved_stdout = dup(1);
                if (dup2(fd, 1) == -1) {
                    state->saved_stdout = -1;
                }
                __fpurge(stdout); //This is used to clear the stdout buffer
            }
        }
    } else if (!strncmp(cmd->args[0], ".load", 5)) {
        if (cmd->args_len == 2) {
            load_table(table, cmd->args[1]);
        }
    } else if (!strncmp(cmd->args[0], ".help", 5)) {
        print_help_msg();
    }
}

///
/// Handle query type commands
/// Return: command type
///
int limit_idx = -1;
int offset_idx = -1;
int from_idx = -1;
int handle_query_cmd(Table_t *table, Command_t *cmd) {
    int idx = 0;
    limit_idx = -1;
    offset_idx = -1;
    id_c = 0;
    name_c = 0;
    email_c = 0;
    age_c = 0;
    coma_total = 0;
    if (!strncmp(cmd->args[0], "insert", 6)) {
        handle_insert_cmd(table, cmd);
        return INSERT_CMD;
    } else if (!strncmp(cmd->args[0], "select", 6)) {
	for(idx = 0; idx<cmd->args_len;idx++){
	    //printf("%s ",cmd->args[idx]);
	    if(strcmp(cmd->args[idx],"limit")==0){
	        limit_idx = idx;	
 	    }
            if(strcmp(cmd->args[idx],"offset")==0){
	        offset_idx = idx;
	    }
	    if(strcmp(cmd->args[idx],"from") == 0){
		from_idx = idx;
	    }
    	}
	if(from_idx != -1){
	    for(int i = 1; i<from_idx;i++){
		if(strcmp(cmd->args[i],"id")==0){
			id_c = 1;
			field_num[i-1] = 0;
			coma_total++;
		}
		else if(strcmp(cmd->args[i],"name")==0){
			name_c = 1;
			field_num[i-1] = 1;
			coma_total++;
		}
		else if(strcmp(cmd->args[i],"email")==0){
			email_c = 1;
			field_num[i-1] = 2;
			coma_total++;
		}
		else if(strcmp(cmd->args[i],"age")==0){
			age_c = 1;
			field_num[i-1] = 3;
			coma_total++;
		}
		else if(strcmp(cmd->args[i],"*")==0){
			id_c = 1;
			name_c = 1;
			email_c = 1;
			age_c = 1;
			coma_total = 4;
			field_num[0] = 0;
			field_num[1] = 1;
			field_num[2] = 2;
			field_num[3] = 3;
		}
	    }
	}
	else{
		id_c = 1;
		name_c = 1;
		email_c = 1;
		age_c = 1;
		coma_total = 4;
		field_num[0] = 0;
		field_num[1] = 1;
		field_num[2] = 2;
		field_num[3] = 3;
	}
        handle_select_cmd(table, cmd);
        return SELECT_CMD;
    } else {
        return UNRECOG_CMD;
    }
}

///
/// The return value is the number of rows insert into table
/// If the insert operation success, then change the input arg
/// `cmd->type` to INSERT_CMD
///
int handle_insert_cmd(Table_t *table, Command_t *cmd) {
    int ret = 0;
    User_t *user = command_to_User(cmd);
    if (user) {
	//
	size_t idx;
	int pri = 0;
	for(idx = 0; idx<table->len; idx++){
	    //printf("%d\n",get_User(table, idx)->id);
	    if(user->id == get_User(table, idx)->id){
	    	pri = 1;
		break;
	    }
	}
	//
	if(pri == 0)
            ret = add_User(table, user);
	//
        if (ret > 0) {
            cmd->type = INSERT_CMD;
        }
    }
    return ret;
}

///
/// The return value is the number of rows select from table
/// If the select operation success, then change the input arg
/// `cmd->type` to SELECT_CMD
///
int handle_select_cmd(Table_t *table, Command_t *cmd) {
    size_t idx;
    int start;
    int end;
    if(limit_idx == -1){
	end = table->len;
    }
    else{
	end = atoi(cmd->args[limit_idx+1]);
    }
    if(offset_idx == -1){
	start = 0;
    }
    else{
        start = atoi(cmd->args[offset_idx+1]);
    }
    for (idx = start; idx < end; idx++) {
        print_user(get_User(table, idx));
    }
    cmd->type = SELECT_CMD;
    return table->len;
}

///
/// Show the help messages
///
void print_help_msg() {
    const char msg[] = "# Supported Commands\n"
    "\n"
    "## Built-in Commands\n"
    "\n"
    "  * .exit\n"
    "\tThis cmd archives the table, if the db file is specified, then exit.\n"
    "\n"
    "  * .output\n"
    "\tThis cmd change the output strategy, default is stdout.\n"
    "\n"
    "\tUsage:\n"
    "\t    .output (<file>|stdout)\n\n"
    "\tThe results will be redirected to <file> if specified, otherwise they will display to stdout.\n"
    "\n"
    "  * .load\n"
    "\tThis command loads records stored in <DB file>.\n"
    "\n"
    "\t*** Warning: This command will overwrite the records already stored in current table. ***\n"
    "\n"
    "\tUsage:\n"
    "\t    .load <DB file>\n\n"
    "\n"
    "  * .help\n"
    "\tThis cmd displays the help messages.\n"
    "\n"
    "## Query Commands\n"
    "\n"
    "  * insert\n"
    "\tThis cmd inserts one user record into table.\n"
    "\n"
    "\tUsage:\n"
    "\t    insert <id> <name> <email> <age>\n"
    "\n"
    "\t** Notice: The <name> & <email> are string without any whitespace character, and maximum length of them is 255. **\n"
    "\n"
    "  * select\n"
    "\tThis cmd will display all user records in the table.\n"
    "\n";
    printf("%s", msg);
}

