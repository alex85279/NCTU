#include <stdio.h>
#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include "Util.h"
#include "Command.h"
#include "Table.h"

///
/// Allocate State_t and initialize some attributes
/// Return: ptr of new State_t
///

int id_c = 1;
int name_c = 1;
int email_c = 1;
int age_c = 1;
int coma_total = 0;
int field_num[10];
char where_cmd[100][100];
int sum;
int count;
double avg_sum;
double avg_count;
int limit_idx = -1;
int offset_idx = -1;
int from_idx = -1;
int where_idx = -1;
int and_idx = -1;
int or_idx = -1;
int sum_idx = -1;
int count_idx = -1;
int avg_idx = -1;
int aggr_flg = 0;
State_t* new_State() {
    State_t *state = (State_t*)malloc(sizeof(State_t));
    state->saved_stdout = -1;
    return state;
}

///
/// Print shell prompt
///
void print_prompt(State_t *state) {
    if (state->saved_stdout == -1) {
        printf("db > ");
    }
}

///
/// Print the user in the specific format
///
void print_user(User_t *user) {
    int tmp_total = coma_total;
    //printf("(%d, %s, %s, %d)\n", user->id, user->name, user->email, user->age);
    /*printf("(");
    if(tmp_total>0 && id_c == 1){
	printf("%d",user->id);
	if(tmp_total>1){
	    printf(", ");		
	}
	tmp_total--;
    }
    if(tmp_total>0 && name_c == 1){
	printf("%s",user->name);
	if(tmp_total>1){
	    printf(", ");		
	}
	tmp_total--;
    }
    if(tmp_total>0 && email_c == 1){
	printf("%s",user->email);
	if(tmp_total>1){
	    printf(", ");		
	}
	tmp_total--;
    }
    if(tmp_total>0 && age_c == 1){
	printf("%d",user->age);
	if(tmp_total>1){
	    printf(", ");		
	}
	tmp_total--;
    }
    printf(")\n");*/

    printf("(");

    for(int i = 0; i<tmp_total;i++){
	if(field_num[i] == 0){
	    printf("%d",user->id);	
	}
	else if(field_num[i] == 1){
	    printf("%s",user->name);	
	}
	else if(field_num[i] == 2){
	    printf("%s",user->email);	
	}
	else if(field_num[i] == 3){
	    printf("%d",user->age);	
	}
	if(i != tmp_total-1){
	    printf(", ");
	}
     }
     printf(")\n");

}
void print_aggre(){
    int tmp_total = coma_total;
    printf("(");
    for(int i = 0; i<tmp_total;i++){
        if(field_num[i] == 0){
 	printf("%d",sum);
    }
	else if(field_num[i] == 1){
	    printf("%d",count);
	}
	else if(field_num[i] == 2){
	    printf("%.3lf",avg_sum/avg_count);
	}
	if(i != tmp_total-1){
	    printf(", ");
	}
    }
    printf(")\n");
}
///
/// This function receivedyan output argument
/// Return: category of the command
///
int parse_input(char *input, Command_t *cmd) {
    char *token;
    int idx;
    token = strtok(input, " \n,");
    for (idx = 0; strlen(cmd_list[idx].name) != 0; idx++) {
        if (!strncmp(token, cmd_list[idx].name, cmd_list[idx].len)) {
            cmd->type = cmd_list[idx].type;
        }
    }
    while (token != NULL) {
        add_Arg(cmd, token);
        token = strtok(NULL, " \n,");
    }
    return cmd->type;
}
int u_where = -1;
int u_set = -1;	
int handle_update_cmd(Table_t *table, Command_t *cmd){
    if(strcmp(cmd->args[0],"update") == 0){
	u_where = -1;
	u_set = -1;
	for(int idx = 0; idx<cmd->args_len;idx++){
	   if(strcmp(cmd->args[idx],"where")==0){
	        u_where = idx;	
 	   }
	   if(strcmp(cmd->args[idx],"set")==0){
	        u_set = idx;	
 	   }
	}
	char field_name[100];
	char field_name_2[100];
	char context[100];
	char blank_name[100];
	strcpy(field_name,cmd->args[u_set+1]);
	strcpy(context, cmd->args[u_set+3]);
	
	if(u_where == -1){
	   for (int idx = 0; idx < table->len; idx++) {
		if(strcmp(field_name,"id")==0){		
		    get_User(table,idx)->id = atoi(context);
		}
		else if(strcmp(field_name,"name")==0){
		    strcpy(get_User(table,idx)->name,context);
		}
		else if(strcmp(field_name,"email")==0){
		    strcpy(get_User(table,idx)->email,context);
		}
		else if(strcmp(field_name,"age")==0){		
		    get_User(table,idx)->age = atoi(context);
		}
	   }
	}
	else {
		strcpy(field_name_2,cmd->args[u_where+1]);
		strcpy(blank_name,cmd->args[u_where+3]);
		for (int idx = 0; idx < table->len; idx++) {
		    if(strcmp(field_name_2,"id")==0 && get_User(table,idx)->id == atoi(blank_name)){
			if(strcmp(field_name,"id")==0){		
			    get_User(table,idx)->id = atoi(context);
			}
			else if(strcmp(field_name,"name")==0){
			    strcpy(get_User(table,idx)->name,context);
			}
			else if(strcmp(field_name,"email")==0){
			    strcpy(get_User(table,idx)->email,context);
			}
			else if(strcmp(field_name,"age")==0){		
			    get_User(table,idx)->age = atoi(context);
			}
			
		    }
		    
		    else if(strcmp(field_name_2,"name")==0 && strcmp(get_User(table,idx)->name,blank_name) == 0){	
			if(strcmp(field_name,"id")==0){		
			    get_User(table,idx)->id = atoi(context);
			}
			else if(strcmp(field_name,"name")==0){
			    strcpy(get_User(table,idx)->name,context);
			}
			else if(strcmp(field_name,"email")==0){
			    strcpy(get_User(table,idx)->email,context);
			}
			else if(strcmp(field_name,"age")==0){		
			    get_User(table,idx)->age = atoi(context);
			}
		    }

		    else if(strcmp(field_name_2,"email")==0 && strcmp(get_User(table,idx)->email,blank_name) == 0){
			
			if(strcmp(field_name,"id")==0){		
			    get_User(table,idx)->id = atoi(context);
			}
			else if(strcmp(field_name,"name")==0){
			    strcpy(get_User(table,idx)->name,context);
			}
			else if(strcmp(field_name,"email")==0){
			    strcpy(get_User(table,idx)->email,context);
			}
			else if(strcmp(field_name,"age")==0){		
			    get_User(table,idx)->age = atoi(context);
			}
		    }
		    else if(strcmp(field_name_2,"age")==0 && get_User(table,idx)->age == atoi(blank_name)){
			
			if(strcmp(field_name,"id")==0){		
			    get_User(table,idx)->id = atoi(context);
			}
			else if(strcmp(field_name,"name")==0){
			    strcpy(get_User(table,idx)->name,context);
			}
			else if(strcmp(field_name,"email")==0){
			    strcpy(get_User(table,idx)->email,context);
			}
			else if(strcmp(field_name,"age")==0){		
			    get_User(table,idx)->age = atoi(context);
			}
		    }
	    }

	}
	return UPDATE_CMD;

    }
    else{
	return UNRECOG_CMD;
    }

    

}
///
/// Handle built-in commands
/// Return: command type
///
void handle_builtin_cmd(Table_t *table, Command_t *cmd, State_t *state) {
    if (!strncmp(cmd->args[0], ".exit", 5)) {
        archive_table(table);
        exit(0);
    } else if (!strncmp(cmd->args[0], ".output", 7)) {
        if (cmd->args_len == 2) {
            if (!strncmp(cmd->args[1], "stdout", 6)) {
                close(1);
                dup2(state->saved_stdout, 1);
                state->saved_stdout = -1;
            } else if (state->saved_stdout == -1) {
                int fd = creat(cmd->args[1], 0644);
                state->saved_stdout = dup(1);
                if (dup2(fd, 1) == -1) {
                    state->saved_stdout = -1;
                }
                __fpurge(stdout); //This is used to clear the stdout buffer
            }
        }
    } else if (!strncmp(cmd->args[0], ".load", 5)) {
        if (cmd->args_len == 2) {
            load_table(table, cmd->args[1]);
        }
    } else if (!strncmp(cmd->args[0], ".help", 5)) {
        print_help_msg();
    }
}

///
/// Handle query type commands
/// Return: command type
///

int handle_delete_cmd(Table_t *table, Command_t *cmd){
    char field[100];
    char op[5];
    char con[100];
    if(where_idx == -1) {
	table-> len = 0;
	return 1;
    }
    strcpy(field,cmd->args[where_idx+1]);
    strcpy(op,cmd->args[where_idx+2]);
    strcpy(con,cmd->args[where_idx+3]);
    for (int idx = 0 ; idx < table->len; idx++){
	int type;
	int tmp_num;
	char tmp_str[100];
	int flg = 0;
	if(strcmp(field,"id")==0){tmp_num = get_User(table,idx)->id; type = 1;}
	else if(strcmp(field,"name")==0){strcpy(tmp_str,get_User(table,idx)->name); type = 2;}
	else if(strcmp(field,"email")==0){strcpy(tmp_str,get_User(table,idx)->email); type = 2;}
	else if(strcmp(field,"age")==0){tmp_num = get_User(table,idx)->age; type = 1;}
	else{break;}
	if(type == 1){
	    if((strcmp(op,"=")==0 && tmp_num == atoi(con)) || 
	       (strcmp(op,">")==0 && tmp_num > atoi(con))  ||
	       (strcmp(op,"<")==0 && tmp_num < atoi(con))  ||
	       (strcmp(op,"!=")==0 && tmp_num != atoi(con))||
	       (strcmp(op,"<=")==0 && tmp_num <= atoi(con))||
	       (strcmp(op,">=")==0 && tmp_num >= atoi(con))		
		){
	    	flg = 1;
	    }
	}
	else{
	    if((strcmp(op,"=")==0 && strcmp(tmp_str,con)==0) || (strcmp(op,"!=")==0 && strcmp(tmp_str,con) != 0)){
		flg = 1;
	    }
	}
	if(flg == 1){
	    for(int i = idx; i < table->len-1;i++){
		get_User(table,i)-> id = get_User(table,i+1)->id;
		get_User(table,i)-> age= get_User(table,i+1)->age;
		strcpy(get_User(table,i)->name,get_User(table,i+1)->name);
		strcpy(get_User(table,i)->email,get_User(table,i+1)->email);
		
	    }
	    idx--;
	    table->len--;
	}

    }
    return 1;
}
char sum_field[10];
char count_field[10];
char avg_field[10];
int handle_query_cmd(Table_t *table, Command_t *cmd) {
    int idx = 0;
    limit_idx = -1;
    offset_idx = -1;
    where_idx = -1;
    id_c = 0;
    name_c = 0;
    email_c = 0;
    age_c = 0;
    coma_total = 0;
    sum_idx = 0;
    count_idx = 0;
    avg_idx = 0;
    aggr_flg = 0;
    if (!strncmp(cmd->args[0], "insert", 6)) {
        handle_insert_cmd(table, cmd);
        return INSERT_CMD;
    } 
    else if (strcmp(cmd->args[0], "delete")==0){
	for(idx = 0; idx<cmd->args_len;idx++){
	    if(strcmp(cmd->args[idx],"where") == 0){
		where_idx = idx;
	    }
	}
	handle_delete_cmd(table, cmd);
    }
    else if (!strncmp(cmd->args[0], "select", 6)) {
	for(idx = 0; idx<cmd->args_len;idx++){
	    //printf("%s ",cmd->args[idx]);
	    if(strcmp(cmd->args[idx],"limit")==0){
	        limit_idx = idx;	
 	    }
            if(strcmp(cmd->args[idx],"offset")==0){
	        offset_idx = idx;
	    }
	    if(strcmp(cmd->args[idx],"from") == 0){
		from_idx = idx;
	    }
	    if(strcmp(cmd->args[idx],"where") == 0){
		where_idx = idx;
	    }
	    if(strcmp(cmd->args[idx],"and") == 0){
		and_idx = idx;
	    }
	    if(strcmp(cmd->args[idx],"or") == 0){
		or_idx = idx;
	    }
    	}
	if(from_idx != -1){
	    for(int i = 1; i<from_idx;i++){
		if(strcmp(cmd->args[i],"id")==0){
		    id_c = 1;
		    field_num[i-1] = 0;
		    coma_total++;
		}
		else if(strcmp(cmd->args[i],"name")==0){
		    name_c = 1;
		    field_num[i-1] = 1;
		    coma_total++;
		}
		else if(strcmp(cmd->args[i],"email")==0){
		    email_c = 1;
		    field_num[i-1] = 2;
		    coma_total++;
		}
		else if(strcmp(cmd->args[i],"age")==0){
		    age_c = 1;
		    field_num[i-1] = 3;
		    coma_total++;
		}
		else if(strcmp(cmd->args[i],"*")==0){
		    id_c = 1;
		    name_c = 1;
		    email_c = 1;
		    age_c = 1;
		    coma_total = 4;
		    field_num[0] = 0;
		    field_num[1] = 1;
		    field_num[2] = 2;
		    field_num[3] = 3;
		}
		else if(strncmp(cmd->args[i],"sum",3)==0){
		    sum_idx = 1;
		    aggr_flg = 1;
		    char* pch;
		    pch = strtok(cmd->args[i],"()");
		    pch = strtok(NULL,"()");
		    strcpy(sum_field,pch);

		    field_num[i-1] = 0;
		    coma_total ++;
		}
		else if(strncmp(cmd->args[i],"count",5)==0){
		    count_idx = 1;
		    aggr_flg = 1;
		    char* pch;
		    pch = strtok(cmd->args[i],"()");
		    pch = strtok(NULL,"()");
		    strcpy(count_field,pch);

		    field_num[i-1] = 1;
		    coma_total ++;
		}
		else if(strncmp(cmd->args[i],"avg",3)==0){
		    avg_idx = 1;
		    aggr_flg = 1;
		    char* pch;
		    pch = strtok(cmd->args[i],"()");
		    pch = strtok(NULL,"()");
		    strcpy(avg_field,pch);

		    field_num[i-1] = 2;
		    coma_total ++;
		}
	    }
	}
	else{
	    id_c = 0;
	    name_c = 0;
	    email_c = 0;
	    age_c = 0;
	    coma_total = 0;
	    field_num[0] = 0;
	    field_num[1] = 1;
	    field_num[2] = 2;
	    field_num[3] = 3;
	
	}
	int tmp_len;
	int tmp_idx = 0;
	if(offset_idx!=-1){
	    tmp_len = offset_idx;   
	}
	else if(limit_idx!=-1){
	    tmp_len = limit_idx;
	}
	else{
	    tmp_len = cmd->args_len;
	}
	if(where_idx != -1){
	    for(int i = where_idx+1;i<tmp_len;i++){
		strcpy(where_cmd[tmp_idx++],cmd->args[i]);
	    }
	}
	
        handle_select_cmd(table, cmd);
        return SELECT_CMD;
    } 
    else {
        return UNRECOG_CMD;
    }
}

///
/// The return value is the number of rows insert into table
/// If the insert operation success, then change the input arg
/// `cmd->type` to INSERT_CMD
///
int handle_insert_cmd(Table_t *table, Command_t *cmd) {
    int ret = 0;
    User_t *user = command_to_User(cmd);
    if (user) {
	//
	size_t idx;
	int pri = 0;
	for(idx = 0; idx<table->len; idx++){
	    //printf("%d\n",get_User(table, idx)->id);
	    if(user->id == get_User(table, idx)->id){
	    	pri = 1;
		break;
	    }
	}
	//
	if(pri == 0)
            ret = add_User(table, user);
	//
        if (ret > 0) {
            cmd->type = INSERT_CMD;
        }
    }
    return ret;
}

///
/// The return value is the number of rows select from table
/// If the select operation success, then change the input arg
/// `cmd->type` to SELECT_CMD
///
int handle_select_cmd(Table_t *table, Command_t *cmd) {
    size_t idx; 
    int limit;
    int offset;
    sum = 0;
    count = 0;
    avg_sum = 0;
    avg_count = 0;
    if(limit_idx == -1){
	limit = -1;
    }
    else{
	limit = atoi(cmd->args[limit_idx+1]);
    }
    if(offset_idx == -1){
	offset = -1;
    }
    else{
        offset = atoi(cmd->args[offset_idx+1]);
    }
    for (idx = 0; idx < table->len; idx++) {
	if(where_idx == -1){ 
	    if(offset>0){
		offset--;
		continue;
	    }
	    if(aggr_flg == 0) print_user(get_User(table, idx));
	    else{		    
		if(sum_idx == 1){
		    if( strcmp(sum_field,"id") == 0){
		        sum += get_User(table,idx)->id;
		    }
		    else if( strcmp(sum_field,"age")==0){
			sum += get_User(table,idx)->age;
		    }
		}
		if(count_idx == 1){
		    count++;
		}
		if(avg_idx == 1){
		    if( strcmp(avg_field,"id") == 0){
			avg_sum += get_User(table,idx)->id;
		    }
		    else if( strcmp(avg_field,"age")==0){
			avg_sum += get_User(table,idx)->age;
		    }
		    avg_count++;
		}		
	    }
	    if(limit!=0){
		limit--;
	    }

	}
	else{
    	    if(and_idx != -1 || or_idx != -1){
		if(strcmp(where_cmd[0],"id") == 0){	 

		    if(strcmp(where_cmd[4],"id") == 0){
			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
					
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }	
					}
					
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
					
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
					
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					   
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
				
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
					
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
					
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
					
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
					
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
					
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
					
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
					
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
					
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	
			    else if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
					
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
					
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
				
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	
			    else if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	
			    else if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	

			    else if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	

			}
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			     else if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }				
			    else if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }

			}
		    } 
		    else if(strcmp(where_cmd[4],"name") == 0){
			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }

			}
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }

			}
		    }
		    else if(strcmp(where_cmd[4],"email") == 0){
  			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			}
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			}
		    }
		    else if(strcmp(where_cmd[4],"age") == 0){
			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	
			    else if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	
			    else if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	
			    else if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	

			    else if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	

			}
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id > atoi(where_cmd[2]) || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id == atoi(where_cmd[2]) || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			     else if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id < atoi(where_cmd[2]) || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id != atoi(where_cmd[2]) || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }				
			    else if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id >= atoi(where_cmd[2]) || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->id <= atoi(where_cmd[2]) || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }

			}
		    }

		}
		else if(strcmp(where_cmd[0],"name") == 0){
		    if(strcmp(where_cmd[4],"id") == 0){
			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
		    	}	
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			}
		    }
		    else if(strcmp(where_cmd[4],"name") == 0){
  			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && strcmp(get_User(table,idx)->name,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && strcmp(get_User(table,idx)->name,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && strcmp(get_User(table,idx)->name,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && strcmp(get_User(table,idx)->name,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
     		 	    }
			}
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || strcmp(get_User(table,idx)->name,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || strcmp(get_User(table,idx)->name,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || strcmp(get_User(table,idx)->name,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || strcmp(get_User(table,idx)->name,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
     		 	    }
			}
		    }

		    else if(strcmp(where_cmd[4],"email") == 0){
  			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && strcmp(get_User(table,idx)->email,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && strcmp(get_User(table,idx)->email,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && strcmp(get_User(table,idx)->email,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && strcmp(get_User(table,idx)->email,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
     		 	    }
			}
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || strcmp(get_User(table,idx)->email,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || strcmp(get_User(table,idx)->email,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || strcmp(get_User(table,idx)->email,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || strcmp(get_User(table,idx)->email,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
     		 	    }
			}
		    }
		    else if(strcmp(where_cmd[4],"age") == 0){
			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
		    	}
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0 || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0 || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			}
		    }
		}
		else if(strcmp(where_cmd[0],"email") == 0){
		    if(strcmp(where_cmd[4],"id") == 0){
			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
		    	}	
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			}
		    }
		    else if(strcmp(where_cmd[4],"name") == 0){
  			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && strcmp(get_User(table,idx)->name,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && strcmp(get_User(table,idx)->name,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && strcmp(get_User(table,idx)->name,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && strcmp(get_User(table,idx)->name,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
     		 	    }
			}
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || strcmp(get_User(table,idx)->name,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || strcmp(get_User(table,idx)->name,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || strcmp(get_User(table,idx)->name,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || strcmp(get_User(table,idx)->name,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
     		 	    }
			}
		    }

		    else if(strcmp(where_cmd[4],"email") == 0){
  			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && strcmp(get_User(table,idx)->email,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && strcmp(get_User(table,idx)->email,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && strcmp(get_User(table,idx)->email,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && strcmp(get_User(table,idx)->email,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
     		 	    }
			}
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || strcmp(get_User(table,idx)->email,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || strcmp(get_User(table,idx)->email,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || strcmp(get_User(table,idx)->email,where_cmd[6]) == 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || strcmp(get_User(table,idx)->email,where_cmd[6]) != 0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
     		 	    }
			}
		    }
		    else if(strcmp(where_cmd[4],"age") == 0){
			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
		    	}
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],"=")==0){
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0 || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else{
				if(strcmp(where_cmd[5],"=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=")==0){
				    if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0 || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			}
		    }
		}

		else if(strcmp(where_cmd[0],"age") == 0){
		   if(strcmp(where_cmd[4],"id") == 0){
			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	
			    else if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	
			    else if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	
			    else if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	

			    else if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	

			}
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			     else if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }				
			    else if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || get_User(table,idx)->id <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || get_User(table,idx)->id == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || get_User(table,idx)->id != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || get_User(table,idx)->id > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || get_User(table,idx)->id < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || get_User(table,idx)->id >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }

			}
		    } 
		    else if(strcmp(where_cmd[4],"name") == 0){
			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }

			}
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }

			}
		    }
		    else if(strcmp(where_cmd[4],"email") == 0){
  			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			}
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || strcmp(get_User(table,idx)->name,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])==0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else{
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || strcmp(get_User(table,idx)->email,where_cmd[6])!=0){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			}
		    }
		    else if(strcmp(where_cmd[4],"age") == 0){
			if(strcmp(where_cmd[3],"and") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	
			    else if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	
			    else if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	
			    else if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	

			    else if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) && get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }	

			}
			else if(strcmp(where_cmd[3],"or") == 0){
			    if(strcmp(where_cmd[1],">") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age > atoi(where_cmd[2]) || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age == atoi(where_cmd[2]) || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			     else if(strcmp(where_cmd[1],"<") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age < atoi(where_cmd[2]) || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"!=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age != atoi(where_cmd[2]) || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }				
			    else if(strcmp(where_cmd[1],">=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age >= atoi(where_cmd[2]) || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }
			    else if(strcmp(where_cmd[1],"<=") == 0){
				if(strcmp(where_cmd[5],"=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || get_User(table,idx)->age == atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"!=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || get_User(table,idx)->age != atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || get_User(table,idx)->age > atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || get_User(table,idx)->age < atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],"<=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || get_User(table,idx)->age <= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
				else if(strcmp(where_cmd[5],">=") == 0){
				    if(get_User(table,idx)->age <= atoi(where_cmd[2]) || get_User(table,idx)->age >= atoi(where_cmd[6])){
					if(offset>0){
					    offset--;
					    continue;
	    		    	 	}
	    		    	        if(aggr_flg == 0) print_user(get_User(table, idx));
					else{
					    
					    if(sum_idx == 1){
						if( strcmp(sum_field,"id") == 0){
						    sum += get_User(table,idx)->id;
						}
						else if( strcmp(sum_field,"age")==0){
						    sum += get_User(table,idx)->age;
						}
					    }
					    if(count_idx == 1){
						count++;
					    }
					    if(avg_idx == 1){
		   				 if( strcmp(avg_field,"id") == 0){
						      avg_sum += get_User(table,idx)->id;
		    				 }
		    				 else if( strcmp(avg_field,"age")==0){
						      avg_sum += get_User(table,idx)->age;
		    				 }
		    				 avg_count++;
					    }		
					}
	    		   		if(limit>0){
			    	    	    limit--;
	    		   		}
				    }
				}
			    }

			}
		    }
		}
	    }
	    else{
		if(strcmp(where_cmd[0],"id") == 0){
		    if(strcmp(where_cmd[1],">") == 0){
			if(get_User(table,idx)->id > atoi(where_cmd[2])){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		    else if(strcmp(where_cmd[1],"=") == 0){
			if(get_User(table,idx)->id == atoi(where_cmd[2])){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		    else if(strcmp(where_cmd[1],"<") == 0){
			if(get_User(table,idx)->id < atoi(where_cmd[2])){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		    else if(strcmp(where_cmd[1],"<=") == 0){
			if(get_User(table,idx)->id <= atoi(where_cmd[2])){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		    else if(strcmp(where_cmd[1],">=") == 0){
			if(get_User(table,idx)->id >= atoi(where_cmd[2])){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		    else if(strcmp(where_cmd[1],"!=") == 0){
			if(get_User(table,idx)->id != atoi(where_cmd[2])){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		}
		else if(strcmp(where_cmd[0],"name") == 0){
		    if(strcmp(where_cmd[1],"=") == 0){
			if(strcmp(get_User(table,idx)->name,where_cmd[2]) == 0){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		    else {
			if(strcmp(get_User(table,idx)->name,where_cmd[2]) != 0){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		}
		else if(strcmp(where_cmd[0],"email") == 0){
		    if(strcmp(where_cmd[1],"=") == 0){
			if(strcmp(get_User(table,idx)->email,where_cmd[2]) == 0){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		    else {
			if(strcmp(get_User(table,idx)->email,where_cmd[2]) != 0){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		}
		else if(strcmp(where_cmd[0],"age") == 0){
		    if(strcmp(where_cmd[1],">") == 0){
			if(get_User(table,idx)->age > atoi(where_cmd[2])){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		    else if(strcmp(where_cmd[1],"=") == 0){
			if(get_User(table,idx)->age == atoi(where_cmd[2])){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		    else if(strcmp(where_cmd[1],"<") == 0){
			if(get_User(table,idx)->age < atoi(where_cmd[2])){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		    else if(strcmp(where_cmd[1],"!=") == 0){
			if(get_User(table,idx)->age != atoi(where_cmd[2])){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		    else if(strcmp(where_cmd[1],">=") == 0){
			if(get_User(table,idx)->age >= atoi(where_cmd[2])){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		    else if(strcmp(where_cmd[1],"<=") == 0){
			if(get_User(table,idx)->age <= atoi(where_cmd[2])){
			    if(offset>0){
				offset--;
				continue;
	    		    }
	    		    if(aggr_flg == 0) print_user(get_User(table, idx));
			    else{
					    
			        if(sum_idx == 1){
			            if( strcmp(sum_field,"id") == 0){
			   	        sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					sum += get_User(table,idx)->age;
				    }
				}
			 	if(count_idx == 1){
				    count++;
				}
				if(avg_idx == 1){
				    if( strcmp(sum_field,"id") == 0){
					avg_sum += get_User(table,idx)->id;
				    }
				    else if( strcmp(sum_field,"age")==0){
					avg_sum += get_User(table,idx)->age;
				    }
				    avg_count++;
				}		
			    }
	    		    if(limit>0){
			        limit--;
	    		    }
			}
		    }
		}
	    }
	}   
	if(limit == 0){
	   break;
	}   
    }
    
    if(aggr_flg == 1) {
	print_aggre();
    }
    cmd->type = SELECT_CMD;
    return table->len;
}

///
/// Show the help messages
///
void print_help_msg() {
    const char msg[] = "# Supported Commands\n"
    "\n"
    "## Built-in Commands\n"
    "\n"
    "  * .exit\n"
    "\tThis cmd archives the table, if the db file is specified, then exit.\n"
    "\n"
    "  * .output\n"
    "\tThis cmd change the output strategy, default is stdout.\n"
    "\n"
    "\tUsage:\n"
    "\t    .output (<file>|stdout)\n\n"
    "\tThe results will be redirected to <file> if specified, otherwise they will display to stdout.\n"
    "\n"
    "  * .load\n"
    "\tThis command loads records stored in <DB file>.\n"
    "\n"
    "\t*** Warning: This command will overwrite the records already stored in current table. ***\n"
    "\n"
    "\tUsage:\n"
    "\t    .load <DB file>\n\n"
    "\n"
    "  * .help\n"
    "\tThis cmd displays the help messages.\n"
    "\n"
    "## Query Commands\n"
    "\n"
    "  * insert\n"
    "\tThis cmd inserts one user record into table.\n"
    "\n"
    "\tUsage:\n"
    "\t    insert <id> <name> <email> <age>\n"
    "\n"
    "\t** Notice: The <name> & <email> are string without any whitespace character, and maximum length of them is 255. **\n"
    "\n"
    "  * select\n"
    "\tThis cmd will display all user records in the table.\n"
    "\n";
    printf("%s", msg);
}

